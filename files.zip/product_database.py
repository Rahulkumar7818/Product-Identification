"""
===================================================
src/product_database.py
Mall Product Identification System
Product Database & Mall Store Mapping
===================================================
SQLite database se product information aur
mall floor/store mapping manage karo.
===================================================
"""

import sqlite3
import json
from pathlib import Path
from typing import List, Dict, Optional
from datetime import datetime
from loguru import logger


# Mall Layout Data
MALL_LAYOUT = {
    "Ground Floor": {
        "zone": "A",
        "categories": ["Clothing Men", "Clothing Women", "Footwear", "Bags Accessories"],
        "stores": {
            "Clothing Men": ["H&M Men", "Zara Men", "Wrogn", "Being Human"],
            "Clothing Women": ["Zara Women", "H&M Women", "AND", "Global Desi"],
            "Footwear": ["Nike", "Adidas", "Bata", "Metro Shoes", "Puma"],
            "Bags Accessories": ["Wildcraft", "Fastrack", "Baggit", "American Tourister"],
        }
    },
    "First Floor": {
        "zone": "B",
        "categories": ["Electronics", "Mobile Phones", "Laptops", "Headphones"],
        "stores": {
            "Electronics": ["Croma", "Reliance Digital", "Vijay Sales"],
            "Mobile Phones": ["Apple Store", "Samsung", "Mi Store", "Oneplus"],
            "Laptops": ["Dell Exclusive", "HP World", "Lenovo Studio", "Croma"],
            "Headphones": ["Sony Center", "Bose", "JBL Store", "Croma"],
        }
    },
    "Second Floor": {
        "zone": "C",
        "categories": ["Watches", "Jewellery", "Cosmetics Beauty", "Books Stationery"],
        "stores": {
            "Watches": ["Titan", "Casio", "Fastrack", "Timex"],
            "Jewellery": ["Tanishq", "Kalyan Jewellers", "Malabar Gold", "CaratLane"],
            "Cosmetics Beauty": ["Nykaa", "MAC", "Lakme Salon", "The Body Shop"],
            "Books Stationery": ["Crossword", "Oxford Bookstore", "Archies"],
        }
    },
    "Third Floor": {
        "zone": "D",
        "categories": ["Sports Equipment", "Toys Games", "Home Appliances", "Kitchen Items"],
        "stores": {
            "Sports Equipment": ["Decathlon", "Sports Station", "Nike Sports", "Puma"],
            "Toys Games": ["Hamleys", "Toy Store", "Kids Store", "Mattel"],
            "Home Appliances": ["LG Showroom", "Samsung Home", "Whirlpool", "Godrej"],
            "Kitchen Items": ["Kitchen World", "Prestige Smart Kitchen", "Cello"],
        }
    },
    "Food Court": {
        "zone": "E",
        "categories": ["Food Snacks", "Beverages"],
        "stores": {
            "Food Snacks": ["McDonald's", "KFC", "Domino's", "Pizza Hut", "Subway"],
            "Beverages": ["Starbucks", "Cafe Coffee Day", "Chaayos", "Juice Junction"],
        }
    }
}


class ProductDatabase:
    """
    SQLite-based Product Database
    
    Tables:
    - products: Product catalog
    - detections: Detection history
    - mall_stores: Store information
    """

    def __init__(self, db_path: str = "data/products.db"):
        self.db_path = db_path
        Path(db_path).parent.mkdir(parents=True, exist_ok=True)
        self._initialize_db()

    def _get_connection(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        return conn

    def _initialize_db(self):
        """Database tables create karo"""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            
            # Products table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS products (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT NOT NULL,
                    brand TEXT,
                    category TEXT NOT NULL,
                    subcategory TEXT,
                    price_min REAL,
                    price_max REAL,
                    floor TEXT,
                    zone TEXT,
                    stores TEXT,          -- JSON array
                    barcode TEXT,
                    description TEXT,
                    features TEXT,        -- JSON array
                    created_at TEXT DEFAULT CURRENT_TIMESTAMP
                )
            """)
            
            # Detection history table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS detection_history (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    image_path TEXT,
                    detected_products TEXT,    -- JSON
                    ocr_text TEXT,
                    barcode_data TEXT,
                    cnn_category TEXT,
                    cnn_confidence REAL,
                    yolo_detections INTEGER,
                    processing_time REAL,
                    detected_at TEXT DEFAULT CURRENT_TIMESTAMP
                )
            """)
            
            conn.commit()
            logger.info("✅ Database initialized!")
            
            # Sample data insert karo agar empty hai
            self._insert_sample_data(cursor, conn)

    def _insert_sample_data(self, cursor, conn):
        """Sample product data insert karo"""
        cursor.execute("SELECT COUNT(*) FROM products")
        count = cursor.fetchone()[0]
        
        if count > 0:
            return  # Already has data
        
        sample_products = [
            ("iPhone 15", "Apple", "Mobile Phones", "Smartphones", 75000, 89999, "First Floor", "B",
             json.dumps(["Apple Store", "Croma", "Reliance Digital"]),
             "194253401971", "Latest Apple smartphone with A16 chip",
             json.dumps(["6.1 inch OLED", "48MP Camera", "USB-C", "iOS 17"])),
            
            ("Samsung Galaxy S24", "Samsung", "Mobile Phones", "Smartphones", 65000, 79999, "First Floor", "B",
             json.dumps(["Samsung", "Croma", "Vijay Sales"]),
             "887276767123", "Android flagship with AI features",
             json.dumps(["6.2 inch Dynamic AMOLED", "50MP Camera", "200MP Ultra", "Android 14"])),
            
            ("Nike Air Max 270", "Nike", "Footwear", "Running Shoes", 9999, 12999, "Ground Floor", "A",
             json.dumps(["Nike", "Sports Station", "Decathlon"]),
             "886914538879", "Iconic Nike running shoes with Air cushioning",
             json.dumps(["Air Max unit", "Breathable mesh", "Rubber outsole", "Lightweight"])),
            
            ("Zara Floral Dress", "Zara", "Clothing Women", "Dresses", 2999, 4999, "Ground Floor", "A",
             json.dumps(["Zara Women"]),
             None, "Elegant floral print summer dress",
             json.dumps(["Floral print", "V-neck", "Midi length", "Cotton blend"])),
            
            ("Titan Raga Watch", "Titan", "Watches", "Analog Watches", 8000, 15000, "Second Floor", "C",
             json.dumps(["Titan", "Fastrack", "World of Titan"]),
             "8907742100001", "Premium women's analog watch",
             json.dumps(["Stainless steel case", "Leather strap", "Sapphire crystal", "Water resistant"])),
            
            ("Tanishq Gold Ring", "Tanishq", "Jewellery", "Rings", 25000, 50000, "Second Floor", "C",
             json.dumps(["Tanishq", "Malabar Gold"]),
             None, "22 Karat gold ring with diamond studding",
             json.dumps(["22K gold", "BIS hallmark", "Diamond studded", "Traditional design"])),
            
            ("Sony WH-1000XM5", "Sony", "Headphones", "Wireless Headphones", 28000, 32000, "First Floor", "B",
             json.dumps(["Sony Center", "Croma", "Reliance Digital"]),
             "027242918573", "Industry-leading noise cancelling headphones",
             json.dumps(["ANC", "30hr battery", "LDAC support", "Quick Charge"])),
            
            ("Dell XPS 15", "Dell", "Laptops", "Premium Laptops", 120000, 150000, "First Floor", "B",
             json.dumps(["Dell Exclusive", "Croma", "HP World"]),
             "884116362845", "High-performance laptop for creators",
             json.dumps(["Intel i7", "16GB RAM", "512GB SSD", "OLED Display"])),
            
            ("MAC Lipstick Ruby Woo", "MAC", "Cosmetics Beauty", "Lipsticks", 1800, 2000, "Second Floor", "C",
             json.dumps(["MAC", "Nykaa", "Sephora"]),
             "773602013241", "Classic red matte lipstick",
             json.dumps(["Matte finish", "Long lasting", "Moisturizing", "Iconic red shade"])),
            
            ("Prestige Cooker 5L", "Prestige", "Kitchen Items", "Pressure Cookers", 1500, 2500, "Third Floor", "D",
             json.dumps(["Prestige Smart Kitchen", "Kitchen World", "Croma"]),
             "8901684023564", "Aluminum pressure cooker with safety valve",
             json.dumps(["5 Liter", "ISI marked", "Safety valve", "10 year warranty"])),
        ]
        
        cursor.executemany("""
            INSERT INTO products 
            (name, brand, category, subcategory, price_min, price_max, floor, zone, stores, barcode, description, features)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, sample_products)
        
        conn.commit()
        logger.info(f"✅ {len(sample_products)} sample products inserted!")

    def search_by_category(self, category: str) -> List[Dict]:
        """Category se products search karo"""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                SELECT * FROM products 
                WHERE category LIKE ? OR subcategory LIKE ?
                ORDER BY name
            """, (f"%{category}%", f"%{category}%"))
            
            rows = cursor.fetchall()
            return [dict(row) for row in rows]

    def search_by_barcode(self, barcode: str) -> Optional[Dict]:
        """Barcode se product search karo"""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM products WHERE barcode = ?", (barcode,))
            row = cursor.fetchone()
            return dict(row) if row else None

    def search_by_name(self, name: str) -> List[Dict]:
        """Product name se search karo"""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                SELECT * FROM products 
                WHERE name LIKE ? OR brand LIKE ?
                ORDER BY name
            """, (f"%{name}%", f"%{name}%"))
            rows = cursor.fetchall()
            return [dict(row) for row in rows]

    def get_mall_location(self, category: str) -> Dict:
        """Category ke liye mall location find karo"""
        category_lower = category.lower()
        
        for floor, info in MALL_LAYOUT.items():
            for cat in info["categories"]:
                if category_lower in cat.lower() or cat.lower() in category_lower:
                    stores = info["stores"].get(cat, [])
                    return {
                        "floor": floor,
                        "zone": info["zone"],
                        "stores": stores,
                        "category": cat
                    }
        
        return {
            "floor": "Ask Information Desk",
            "zone": "N/A",
            "stores": ["Information Desk"],
            "category": category
        }

    def save_detection(self, detection_data: Dict) -> int:
        """Detection result database mein save karo"""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO detection_history 
                (image_path, detected_products, ocr_text, barcode_data, 
                 cnn_category, cnn_confidence, yolo_detections, processing_time)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                detection_data.get("image_path", ""),
                json.dumps(detection_data.get("detected_products", [])),
                detection_data.get("ocr_text", ""),
                detection_data.get("barcode_data", ""),
                detection_data.get("cnn_category", ""),
                detection_data.get("cnn_confidence", 0.0),
                detection_data.get("yolo_detections", 0),
                detection_data.get("processing_time", 0.0)
            ))
            conn.commit()
            return cursor.lastrowid

    def get_detection_history(self, limit: int = 10) -> List[Dict]:
        """Recent detections history"""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                SELECT * FROM detection_history 
                ORDER BY detected_at DESC 
                LIMIT ?
            """, (limit,))
            rows = cursor.fetchall()
            return [dict(row) for row in rows]

    def get_stats(self) -> Dict:
        """Database statistics"""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            
            cursor.execute("SELECT COUNT(*) FROM products")
            total_products = cursor.fetchone()[0]
            
            cursor.execute("SELECT COUNT(*) FROM detection_history")
            total_detections = cursor.fetchone()[0]
            
            cursor.execute("SELECT category, COUNT(*) as count FROM products GROUP BY category ORDER BY count DESC")
            categories = cursor.fetchall()
            
            return {
                "total_products": total_products,
                "total_detections": total_detections,
                "categories": {row[0]: row[1] for row in categories}
            }
