# 🛍️ Mall Product Identification System

## AI-powered Product Detection using YOLOv8 + CNN + OCR + Deep Learning

---

## 📋 Project Overview

Yeh project ek **Shopping Mall** ke liye complete AI-based product identification system hai jo product ki photo upload karne par:

- Product detect karta hai (YOLO)
- Category predict karta hai (Deep Learning CNN)
- Labels/text read karta hai (OCR)
- Barcodes scan karta hai
- Mall mein product kahan milega batata hai (Database)

---

## 🏗️ System Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                   INPUT: Product Image                       │
└──────────────────────────┬──────────────────────────────────┘
                           │
         ┌─────────────────┼──────────────────┐
         ▼                 ▼                  ▼
  ┌─────────────┐  ┌─────────────┐  ┌──────────────────┐
  │  YOLOv8     │  │   CNN       │  │  OCR Engine      │
  │  Object     │  │ MobileNetV3 │  │  EasyOCR +       │
  │  Detection  │  │ ResNet50    │  │  Tesseract +     │
  │             │  │ EffNetB0    │  │  pyzbar (Barcode)│
  └──────┬──────┘  └──────┬──────┘  └────────┬─────────┘
         │                │                  │
         └────────────────┼──────────────────┘
                          ▼
              ┌───────────────────────┐
              │   Product Database    │
              │   (SQLite)            │
              │   Mall Store Mapping  │
              └───────────┬───────────┘
                          ▼
              ┌───────────────────────┐
              │   OUTPUT RESULTS      │
              │ • Product Name        │
              │ • Category + Price    │
              │ • Mall Floor/Zone     │
              │ • Nearby Stores       │
              │ • Barcode Data        │
              └───────────────────────┘
```

---

## 📁 Project Structure

```
mall_product_identification/
│
├── app.py                  ← Streamlit Web App (Main UI)
├── train.py                ← Model Training Script
├── requirements.txt        ← Python dependencies
│
├── src/                    ← Core Source Code
│   ├── __init__.py
│   ├── pipeline.py         ← Main identification pipeline
│   ├── yolo_detector.py    ← YOLOv8 detection module
│   ├── cnn_classifier.py   ← CNN deep learning classifier
│   ├── ocr_module.py       ← OCR + Barcode reading
│   └── product_database.py ← SQLite DB + Mall mapping
│
├── config/                 ← Configuration files
│   ├── config.yaml         ← Main config
│   └── product_classes.txt ← 20 product categories
│
├── models/                 ← Saved ML models
│   ├── product_classifier.pth   ← CNN model (after training)
│   └── product_yolo.pt          ← Custom YOLO (after training)
│
├── data/                   ← Data directory
│   ├── products.db         ← SQLite database
│   ├── sample_images/      ← Test images
│   └── dataset/            ← Training dataset
│       ├── train/
│       │   ├── Electronics/
│       │   ├── Mobile_Phones/
│       │   └── ...
│       └── val/
│
├── notebooks/
│   └── training_demo.ipynb ← Jupyter training notebook
│
└── outputs/                ← Detection results save honge
```

---

## 🚀 Quick Start

### Step 1: Install Dependencies

```bash
# Virtual environment banao
python -m venv mall_env
source mall_env/bin/activate  # Linux/Mac
# mall_env\Scripts\activate   # Windows

# Dependencies install karo
pip install -r requirements.txt

# Tesseract install karo (OCR ke liye)
# Ubuntu/Debian:
sudo apt-get install tesseract-ocr

# Windows: https://github.com/UB-Mannheim/tesseract/wiki
```

### Step 2: App Run Karo

```bash
streamlit run app.py
```

Browser mein `http://localhost:8501` open karo.

---

## 🧠 AI Models Details

### 1. YOLOv8 (Object Detection)

| Model | Size | Speed | mAP50 |
|-------|------|-------|-------|
| YOLOv8n | 6.3MB | 0.9ms | 37.3 |
| YOLOv8s | 22.5MB | 1.8ms | 44.9 |
| YOLOv8m | 52MB | 3.2ms | 50.2 |

```python
from src.yolo_detector import YOLODetector

detector = YOLODetector(model_path="yolov8n.pt", confidence=0.45)
image, detections = detector.detect_from_path("product.jpg")
print(f"Detected: {len(detections)} objects")
```

### 2. CNN Classifier (Deep Learning)

| Architecture | Params | Accuracy | Speed |
|---|---|---|---|
| MobileNetV3 Small | 2.5M | ~85% | ~15ms |
| ResNet50 | 25M | ~90% | ~25ms |
| EfficientNet B0 | 5.3M | ~88% | ~20ms |

```python
from src.cnn_classifier import ProductClassifier

classifier = ProductClassifier(model_path="models/product_classifier.pth")
predictions = classifier.predict(image, top_k=5)
print(f"Category: {predictions[0]['category']} ({predictions[0]['confidence_pct']})")
```

### 3. OCR Engine (Text Recognition)

```python
from src.ocr_module import OCREngine

ocr = OCREngine(use_easyocr=True, languages=["en", "hi"])
analysis = ocr.analyze_product_text(image)
print(f"Text: {analysis['full_text']}")
print(f"Prices: {analysis['prices']}")
print(f"Barcodes: {analysis['barcodes']}")
```

---

## 🏋️ Model Training

### CNN Training

```bash
# Default (MobileNetV3, 50 epochs)
python train.py --mode train_cnn --epochs 50

# ResNet50 pe train karo
python train.py --mode train_cnn --cnn_model resnet50 --epochs 100 --batch_size 32

# GPU pe train karo
python train.py --mode train_cnn --device cuda --epochs 100
```

### YOLO Custom Training

```bash
# Pehle dataset prepare karo
python train.py --mode train_yolo --epochs 100

# data/dataset/dataset.yaml mein apna dataset configure karo
```

### Custom Dataset Datasets

Kuch free datasets:

| Dataset | Classes | Size | Download |
|---|---|---|---|
| Fashion MNIST | 10 | 70K images | Kaggle |
| Stanford Products | 120 | 120K images | Stanford |
| Open Images V7 | 600 | 9M images | Google |
| DeepFashion | 50 | 800K images | CUHK |

```bash
# Kaggle se Fashion dataset download karo
pip install kaggle
kaggle datasets download paramaggarwal/fashion-product-images-small
```

---

## 📊 20 Product Categories

```
0: Electronics      1: Mobile Phones    2: Laptops
3: Headphones       4: Clothing Men     5: Clothing Women
6: Footwear         7: Bags Accessories 8: Watches
9: Jewellery       10: Food Snacks     11: Beverages
12: Cosmetics      13: Toys Games      14: Books
15: Sports         16: Home Appliances 17: Kitchen Items
18: Medicines      19: Others
```

---

## 🏬 Mall Floor Mapping

| Floor | Zone | Categories |
|---|---|---|
| Ground Floor | A | Fashion, Footwear, Bags |
| 1st Floor | B | Electronics, Mobile, Laptops |
| 2nd Floor | C | Watches, Jewellery, Beauty |
| 3rd Floor | D | Sports, Toys, Home Appliances |
| Food Court | E | Food, Beverages |

---

## 💡 Usage Example

```python
from src.pipeline import ProductIdentificationPipeline
import cv2

# Pipeline initialize karo
pipeline = ProductIdentificationPipeline(
    enable_yolo=True,
    enable_ocr=True,
    enable_cnn=True
)

# Image se product identify karo
image = cv2.imread("product.jpg")
result = pipeline.identify(image)

print(f"Product: {result.product_name}")
print(f"Category: {result.primary_category}")
print(f"Floor: {result.mall_location['floor']}")
print(f"Zone: {result.mall_location['zone']}")
print(f"Stores: {result.mall_location['stores']}")
print(f"OCR Text: {result.ocr_text}")
print(f"Price: {result.detected_prices}")
print(f"Time: {result.processing_time:.3f}s")
```

---

## 🤝 Contributors

Mall Product Identification System — Built with ❤️ using:
- **PyTorch** — Deep Learning
- **Ultralytics YOLOv8** — Object Detection
- **EasyOCR** — Text Recognition
- **Streamlit** — Web Interface
- **SQLite** — Product Database

---

## 📄 License

MIT License — Free for educational and commercial use.
