"""
===================================================
src/pipeline.py
Mall Product Identification System
Main Identification Pipeline
===================================================
YOLO + OCR + CNN sab ko combine karke
complete product identification karo.
===================================================
"""

import cv2
import numpy as np
import time
from typing import Dict, List, Optional, Tuple
from pathlib import Path
from loguru import logger
from dataclasses import dataclass, field

from .yolo_detector import YOLODetector, Detection
from .ocr_module import OCREngine
from .cnn_classifier import ProductClassifier
from .product_database import ProductDatabase, MALL_LAYOUT


@dataclass
class ProductIdentificationResult:
    """Complete product identification ka result"""
    
    # Input info
    image_path: str = ""
    processing_time: float = 0.0
    
    # YOLO Results
    yolo_detections: List[Detection] = field(default_factory=list)
    yolo_annotated_image: Optional[np.ndarray] = None
    
    # CNN Results (main product ke liye)
    cnn_predictions: List[Dict] = field(default_factory=list)
    primary_category: str = "Unknown"
    category_confidence: float = 0.0
    
    # OCR Results
    ocr_text: str = ""
    detected_prices: List[str] = field(default_factory=list)
    detected_brands: List[str] = field(default_factory=list)
    barcodes: List[Dict] = field(default_factory=list)
    
    # Database Match
    db_matches: List[Dict] = field(default_factory=list)
    barcode_match: Optional[Dict] = None
    
    # Mall Location
    mall_location: Dict = field(default_factory=dict)
    
    # Summary
    product_name: str = "Unknown Product"
    confidence_level: str = "Low"
    summary: str = ""

    def to_dict(self) -> Dict:
        return {
            "processing_time": round(self.processing_time, 3),
            "yolo_objects_detected": len(self.yolo_detections),
            "primary_category": self.primary_category,
            "category_confidence": round(self.category_confidence, 3),
            "cnn_predictions": self.cnn_predictions[:3],
            "ocr_text": self.ocr_text,
            "detected_prices": self.detected_prices,
            "detected_brands": self.detected_brands,
            "barcodes": self.barcodes,
            "db_matches": self.db_matches[:3],
            "mall_location": self.mall_location,
            "product_name": self.product_name,
            "confidence_level": self.confidence_level,
            "summary": self.summary,
        }


class ProductIdentificationPipeline:
    """
    Complete Product Identification Pipeline
    
    Pipeline Steps:
    1. Image Preprocessing
    2. YOLO Object Detection → Products detect karo
    3. CNN Classification → Category predict karo
    4. OCR Text Extraction → Labels, prices, brands padho
    5. Barcode Reading → Product code scan karo
    6. Database Lookup → Product info fetch karo
    7. Mall Location Mapping → Kahan milega batao
    8. Result Synthesis → Sab combine karo
    """

    def __init__(self,
                 yolo_model: str = "yolov8n.pt",
                 cnn_model: str = None,
                 db_path: str = "data/products.db",
                 enable_ocr: bool = True,
                 enable_yolo: bool = True,
                 enable_cnn: bool = True,
                 device: str = "cpu"):
        
        logger.info("🚀 Initializing Mall Product Identification Pipeline...")
        
        self.enable_yolo = enable_yolo
        self.enable_ocr = enable_ocr
        self.enable_cnn = enable_cnn
        
        # Initialize components
        if enable_yolo:
            try:
                self.yolo = YOLODetector(
                    model_path=yolo_model,
                    confidence=0.45,
                    device=device
                )
                logger.success("✅ YOLO Detector ready")
            except Exception as e:
                logger.warning(f"YOLO not available: {e}")
                self.enable_yolo = False
                self.yolo = None

        if enable_ocr:
            try:
                self.ocr = OCREngine(
                    use_easyocr=True,
                    use_tesseract=False,
                    languages=["en"],
                    gpu=(device == "cuda")
                )
                logger.success("✅ OCR Engine ready")
            except Exception as e:
                logger.warning(f"OCR not available: {e}")
                self.enable_ocr = False
                self.ocr = None

        if enable_cnn:
            try:
                self.classifier = ProductClassifier(
                    model_path=cnn_model,
                    device=device
                )
                logger.success("✅ CNN Classifier ready")
            except Exception as e:
                logger.warning(f"CNN not available: {e}")
                self.enable_cnn = False
                self.classifier = None

        # Database always available
        self.db = ProductDatabase(db_path)
        logger.success("✅ Database ready")
        logger.success("🎉 Pipeline initialized successfully!")

    def identify(self, image: np.ndarray,
                 image_path: str = "") -> ProductIdentificationResult:
        """
        Main identification function
        
        Args:
            image: BGR numpy array (OpenCV format)
            image_path: Optional image file path for logging
            
        Returns:
            ProductIdentificationResult with complete analysis
        """
        start_time = time.time()
        result = ProductIdentificationResult(image_path=image_path)
        
        logger.info(f"Processing image: {image_path or 'from memory'}")
        
        # ─── Step 1: YOLO Detection ────────────────────────────
        if self.enable_yolo and self.yolo:
            logger.info("Step 1/5: YOLO Object Detection...")
            try:
                detections = self.yolo.detect(image)
                result.yolo_detections = detections
                
                if detections:
                    result.yolo_annotated_image = self.yolo.draw_detections(image, detections)
                    logger.info(f"  → {len(detections)} objects detected")
                else:
                    result.yolo_annotated_image = image.copy()
                    logger.info("  → No objects detected")
            except Exception as e:
                logger.error(f"YOLO error: {e}")
                result.yolo_annotated_image = image.copy()
        else:
            result.yolo_annotated_image = image.copy()

        # ─── Step 2: CNN Classification ───────────────────────
        if self.enable_cnn and self.classifier:
            logger.info("Step 2/5: CNN Classification...")
            try:
                predictions = self.classifier.predict(image, top_k=5)
                result.cnn_predictions = predictions
                
                if predictions:
                    top_pred = predictions[0]
                    result.primary_category = top_pred["category"]
                    result.category_confidence = top_pred["confidence"]
                    logger.info(f"  → Category: {result.primary_category} ({result.category_confidence:.2%})")
            except Exception as e:
                logger.error(f"CNN error: {e}")

        # ─── Step 3: OCR Text Extraction ──────────────────────
        if self.enable_ocr and self.ocr:
            logger.info("Step 3/5: OCR Text Extraction...")
            try:
                ocr_analysis = self.ocr.analyze_product_text(image)
                result.ocr_text = ocr_analysis.get("full_text", "")
                result.detected_prices = ocr_analysis.get("prices", [])
                result.detected_brands = ocr_analysis.get("brands", [])
                result.barcodes = ocr_analysis.get("barcodes", [])
                
                logger.info(f"  → Text: '{result.ocr_text[:50]}...' | Prices: {result.detected_prices} | Barcodes: {len(result.barcodes)}")
            except Exception as e:
                logger.error(f"OCR error: {e}")

        # ─── Step 4: Database Lookup ───────────────────────────
        logger.info("Step 4/5: Database Lookup...")
        try:
            # Barcode se exact match dhundho
            for barcode_info in result.barcodes:
                match = self.db.search_by_barcode(barcode_info["data"])
                if match:
                    result.barcode_match = match
                    logger.info(f"  → Barcode match: {match['name']}")
                    break

            # Brand/text se search karo
            if result.detected_brands:
                for brand in result.detected_brands[:2]:
                    matches = self.db.search_by_name(brand)
                    result.db_matches.extend(matches)

            # Category se search karo
            if result.primary_category != "Unknown" and not result.db_matches:
                cat_matches = self.db.search_by_category(result.primary_category)
                result.db_matches.extend(cat_matches[:5])
            
            # Duplicates remove karo
            seen_ids = set()
            unique_matches = []
            for m in result.db_matches:
                if m.get("id") not in seen_ids:
                    seen_ids.add(m.get("id"))
                    unique_matches.append(m)
            result.db_matches = unique_matches

        except Exception as e:
            logger.error(f"Database lookup error: {e}")

        # ─── Step 5: Mall Location Mapping ────────────────────
        logger.info("Step 5/5: Mall Location Mapping...")
        try:
            # Priority: Barcode match > DB match > CNN category
            if result.barcode_match:
                result.mall_location = {
                    "floor": result.barcode_match.get("floor", "Unknown"),
                    "zone": result.barcode_match.get("zone", "Unknown"),
                    "stores": [],
                    "from": "barcode_match"
                }
                import json
                stores_json = result.barcode_match.get("stores", "[]")
                try:
                    result.mall_location["stores"] = json.loads(stores_json)
                except:
                    pass
                    
            elif result.db_matches:
                first_match = result.db_matches[0]
                result.mall_location = {
                    "floor": first_match.get("floor", "Unknown"),
                    "zone": first_match.get("zone", "Unknown"),
                    "stores": [],
                    "from": "db_match"
                }
                import json
                try:
                    result.mall_location["stores"] = json.loads(first_match.get("stores", "[]"))
                except:
                    pass
                    
            elif result.primary_category != "Unknown":
                result.mall_location = self.db.get_mall_location(result.primary_category)
                result.mall_location["from"] = "category"
            
            logger.info(f"  → Location: {result.mall_location.get('floor')} | Zone {result.mall_location.get('zone')}")
            
        except Exception as e:
            logger.error(f"Location mapping error: {e}")

        # ─── Final: Synthesize Results ─────────────────────────
        result.processing_time = time.time() - start_time
        self._synthesize_result(result)
        
        # Database mein save karo
        try:
            self.db.save_detection({
                "image_path": image_path,
                "detected_products": [d.class_name for d in result.yolo_detections],
                "ocr_text": result.ocr_text,
                "barcode_data": str(result.barcodes),
                "cnn_category": result.primary_category,
                "cnn_confidence": result.category_confidence,
                "yolo_detections": len(result.yolo_detections),
                "processing_time": result.processing_time
            })
        except Exception as e:
            logger.warning(f"Detection save error: {e}")
        
        logger.success(f"✅ Identification complete in {result.processing_time:.2f}s")
        return result

    def _synthesize_result(self, result: ProductIdentificationResult):
        """Sabhi results combine karke final answer banao"""
        
        # Product name determine karo
        if result.barcode_match:
            result.product_name = f"{result.barcode_match.get('brand', '')} {result.barcode_match.get('name', '')}".strip()
            result.confidence_level = "Very High"
        elif result.db_matches:
            top_match = result.db_matches[0]
            result.product_name = f"{top_match.get('brand', '')} {top_match.get('name', '')}".strip()
            result.confidence_level = "High"
        elif result.detected_brands:
            result.product_name = f"{result.detected_brands[0]} Product"
            result.confidence_level = "Medium"
        elif result.primary_category != "Unknown" and result.category_confidence > 0.6:
            result.product_name = result.primary_category
            result.confidence_level = "Medium"
        else:
            result.product_name = "Unknown Product"
            result.confidence_level = "Low"
        
        # Summary banao
        parts = []
        if result.product_name != "Unknown Product":
            parts.append(f"Product: {result.product_name}")
        if result.primary_category != "Unknown":
            parts.append(f"Category: {result.primary_category}")
        if result.detected_prices:
            parts.append(f"Price: {result.detected_prices[0]}")
        if result.mall_location.get("floor"):
            parts.append(f"Available at: {result.mall_location['floor']}, Zone {result.mall_location.get('zone')}")
        if result.barcodes:
            parts.append(f"Barcode: {result.barcodes[0]['data']}")
        
        result.summary = " | ".join(parts) if parts else "Product identification successful"

    def identify_from_path(self, image_path: str) -> ProductIdentificationResult:
        """File path se image identify karo"""
        image = cv2.imread(image_path)
        if image is None:
            raise FileNotFoundError(f"Image load nahi hua: {image_path}")
        return self.identify(image, image_path=image_path)

    def identify_from_bytes(self, image_bytes: bytes) -> ProductIdentificationResult:
        """Bytes se image identify karo (Streamlit upload ke liye)"""
        nparr = np.frombuffer(image_bytes, np.uint8)
        image = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
        if image is None:
            raise ValueError("Image decode nahi hua")
        return self.identify(image)
