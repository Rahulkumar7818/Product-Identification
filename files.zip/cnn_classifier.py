"""
===================================================
src/cnn_classifier.py
Mall Product Identification System
CNN Deep Learning Classifier Module
===================================================
Transfer Learning using MobileNetV3/ResNet50/EfficientNet
Product categories classify karne ke liye.
===================================================
"""

import os
import torch
import torch.nn as nn
import torch.optim as optim
import torchvision.transforms as transforms
import torchvision.models as models
import numpy as np
import cv2
from pathlib import Path
from typing import List, Dict, Tuple, Optional
from loguru import logger
from torch.utils.data import DataLoader, Dataset
from PIL import Image
import json


# ===================================================
# Product Categories
# ===================================================
PRODUCT_CATEGORIES = [
    "Electronics", "Mobile Phones", "Laptops", "Headphones",
    "Clothing Men", "Clothing Women", "Footwear", "Bags Accessories",
    "Watches", "Jewellery", "Food Snacks", "Beverages",
    "Cosmetics Beauty", "Toys Games", "Books Stationery",
    "Sports Equipment", "Home Appliances", "Kitchen Items",
    "Medicines Healthcare", "Others"
]

NUM_CLASSES = len(PRODUCT_CATEGORIES)


# ===================================================
# Custom Dataset Class
# ===================================================
class ProductDataset(Dataset):
    """
    Custom Dataset for Mall Products
    
    Directory structure expected:
    data/dataset/
        train/
            Electronics/
                img1.jpg
                img2.jpg
            Mobile_Phones/
                img1.jpg
            ...
        val/
            ...
    """

    def __init__(self, root_dir: str, transform=None, split: str = "train"):
        self.root_dir = Path(root_dir) / split
        self.transform = transform
        self.split = split
        self.samples = []
        self.class_to_idx = {}
        self._load_samples()

    def _load_samples(self):
        """Dataset se images aur labels load karo"""
        if not self.root_dir.exists():
            logger.warning(f"Dataset directory nahi mila: {self.root_dir}")
            return
        
        classes = sorted([d.name for d in self.root_dir.iterdir() if d.is_dir()])
        self.class_to_idx = {cls: idx for idx, cls in enumerate(classes)}
        
        for class_name, class_idx in self.class_to_idx.items():
            class_dir = self.root_dir / class_name
            for ext in ["*.jpg", "*.jpeg", "*.png", "*.webp", "*.bmp"]:
                for img_path in class_dir.glob(ext):
                    self.samples.append((str(img_path), class_idx))
        
        logger.info(f"{self.split}: {len(self.samples)} images, {len(self.class_to_idx)} classes")

    def __len__(self):
        return len(self.samples)

    def __getitem__(self, idx):
        img_path, label = self.samples[idx]
        
        try:
            image = Image.open(img_path).convert('RGB')
        except Exception as e:
            logger.warning(f"Image load error {img_path}: {e}")
            image = Image.new('RGB', (224, 224), color=(128, 128, 128))
        
        if self.transform:
            image = self.transform(image)
        
        return image, label


# ===================================================
# Model Architectures
# ===================================================
class ProductClassifierModel(nn.Module):
    """
    Transfer Learning based Product Classifier
    
    Backbone options:
    - MobileNetV3 Small (fastest, mobile-friendly)
    - ResNet50 (balanced accuracy/speed)
    - EfficientNet B0 (best accuracy/params ratio)
    """

    def __init__(self, model_name: str = "mobilenet_v3_small",
                 num_classes: int = NUM_CLASSES,
                 pretrained: bool = True,
                 dropout: float = 0.3):
        super().__init__()
        
        self.model_name = model_name
        self.num_classes = num_classes
        
        # Backbone load karo
        if model_name == "mobilenet_v3_small":
            weights = models.MobileNet_V3_Small_Weights.DEFAULT if pretrained else None
            backbone = models.mobilenet_v3_small(weights=weights)
            in_features = backbone.classifier[3].in_features
            backbone.classifier[3] = nn.Identity()
            self.backbone = backbone
            
            self.classifier = nn.Sequential(
                nn.Dropout(dropout),
                nn.Linear(in_features, 512),
                nn.Hardswish(),
                nn.Dropout(dropout / 2),
                nn.Linear(512, num_classes)
            )
            
        elif model_name == "resnet50":
            weights = models.ResNet50_Weights.DEFAULT if pretrained else None
            backbone = models.resnet50(weights=weights)
            in_features = backbone.fc.in_features
            backbone.fc = nn.Identity()
            self.backbone = backbone
            
            self.classifier = nn.Sequential(
                nn.Dropout(dropout),
                nn.Linear(in_features, 512),
                nn.ReLU(inplace=True),
                nn.Dropout(dropout / 2),
                nn.Linear(512, num_classes)
            )
            
        elif model_name == "efficientnet_b0":
            weights = models.EfficientNet_B0_Weights.DEFAULT if pretrained else None
            backbone = models.efficientnet_b0(weights=weights)
            in_features = backbone.classifier[1].in_features
            backbone.classifier[1] = nn.Identity()
            self.backbone = backbone
            
            self.classifier = nn.Sequential(
                nn.Dropout(dropout),
                nn.Linear(in_features, 512),
                nn.SiLU(),
                nn.Dropout(dropout / 2),
                nn.Linear(512, num_classes)
            )
        else:
            raise ValueError(f"Unknown model: {model_name}. Use: mobilenet_v3_small, resnet50, efficientnet_b0")

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        features = self.backbone(x)
        output = self.classifier(features)
        return output

    def freeze_backbone(self):
        """Backbone freeze karo - sirf classifier train hoga"""
        for param in self.backbone.parameters():
            param.requires_grad = False
        logger.info("Backbone frozen - only classifier will train")

    def unfreeze_backbone(self):
        """Full model train karne ke liye unfreeze"""
        for param in self.backbone.parameters():
            param.requires_grad = True
        logger.info("Full model unfrozen for fine-tuning")


# ===================================================
# Data Transforms
# ===================================================
def get_transforms(split: str = "train", img_size: int = 224) -> transforms.Compose:
    """
    Training aur Validation ke liye transforms define karo
    Data augmentation for better generalization
    """
    if split == "train":
        return transforms.Compose([
            transforms.Resize((img_size + 32, img_size + 32)),
            transforms.RandomCrop(img_size),
            transforms.RandomHorizontalFlip(p=0.5),
            transforms.RandomRotation(15),
            transforms.ColorJitter(brightness=0.3, contrast=0.3, saturation=0.2, hue=0.1),
            transforms.RandomGrayscale(p=0.1),
            transforms.RandomAffine(degrees=0, translate=(0.1, 0.1)),
            transforms.ToTensor(),
            transforms.Normalize(
                mean=[0.485, 0.456, 0.406],
                std=[0.229, 0.224, 0.225]
            ),
            transforms.RandomErasing(p=0.1),  # Occlusion simulation
        ])
    else:  # val / test
        return transforms.Compose([
            transforms.Resize((img_size, img_size)),
            transforms.ToTensor(),
            transforms.Normalize(
                mean=[0.485, 0.456, 0.406],
                std=[0.229, 0.224, 0.225]
            )
        ])


# ===================================================
# Trainer Class
# ===================================================
class CNNTrainer:
    """
    CNN Model Training aur Evaluation Manager
    
    Features:
    - Transfer learning with frozen backbone
    - Learning rate scheduling
    - Early stopping
    - Model checkpointing
    - Training metrics logging
    """

    def __init__(self, model_name: str = "mobilenet_v3_small",
                 num_classes: int = NUM_CLASSES,
                 device: str = None):
        
        self.device = device or ("cuda" if torch.cuda.is_available() else "cpu")
        logger.info(f"Training device: {self.device}")
        
        self.model = ProductClassifierModel(
            model_name=model_name,
            num_classes=num_classes,
            pretrained=True
        ).to(self.device)
        
        self.history = {
            "train_loss": [], "train_acc": [],
            "val_loss": [], "val_acc": []
        }

    def train(self, data_dir: str, epochs: int = 50,
              batch_size: int = 32, lr: float = 0.001,
              save_path: str = "models/product_classifier.pth",
              freeze_epochs: int = 5):
        """
        Model train karo
        
        Strategy:
        1. Pehle backbone freeze karke sirf classifier train karo (freeze_epochs)
        2. Phir full model fine-tune karo reduced LR pe
        
        Args:
            data_dir: Dataset root directory
            epochs: Total training epochs
            batch_size: Batch size
            lr: Initial learning rate
            save_path: Best model save path
            freeze_epochs: Kitne epochs backbone frozen rakho
        """
        # Datasets
        train_dataset = ProductDataset(data_dir, get_transforms("train"), "train")
        val_dataset = ProductDataset(data_dir, get_transforms("val"), "val")
        
        if len(train_dataset) == 0:
            logger.error("Training data nahi mila!")
            return
        
        train_loader = DataLoader(
            train_dataset, batch_size=batch_size,
            shuffle=True, num_workers=4, pin_memory=True
        )
        val_loader = DataLoader(
            val_dataset, batch_size=batch_size,
            shuffle=False, num_workers=4, pin_memory=True
        )
        
        # Loss function
        criterion = nn.CrossEntropyLoss(label_smoothing=0.1)
        
        # Phase 1: Frozen backbone training
        logger.info(f"Phase 1: Backbone frozen training ({freeze_epochs} epochs)")
        self.model.freeze_backbone()
        
        optimizer = optim.AdamW(
            filter(lambda p: p.requires_grad, self.model.parameters()),
            lr=lr, weight_decay=0.01
        )
        scheduler = optim.lr_scheduler.OneCycleLR(
            optimizer, max_lr=lr,
            steps_per_epoch=len(train_loader),
            epochs=freeze_epochs
        )
        
        best_val_acc = 0.0
        
        for epoch in range(1, freeze_epochs + 1):
            train_loss, train_acc = self._train_epoch(train_loader, optimizer, criterion, scheduler)
            val_loss, val_acc = self._val_epoch(val_loader, criterion)
            
            self.history["train_loss"].append(train_loss)
            self.history["train_acc"].append(train_acc)
            self.history["val_loss"].append(val_loss)
            self.history["val_acc"].append(val_acc)
            
            logger.info(f"Epoch {epoch}/{freeze_epochs} | "
                       f"Train Loss: {train_loss:.4f} Acc: {train_acc:.2f}% | "
                       f"Val Loss: {val_loss:.4f} Acc: {val_acc:.2f}%")
        
        # Phase 2: Full model fine-tuning
        logger.info(f"Phase 2: Full model fine-tuning ({epochs - freeze_epochs} epochs)")
        self.model.unfreeze_backbone()
        
        optimizer = optim.AdamW(
            self.model.parameters(),
            lr=lr * 0.1,
            weight_decay=0.01
        )
        scheduler = optim.lr_scheduler.CosineAnnealingLR(
            optimizer,
            T_max=epochs - freeze_epochs,
            eta_min=1e-6
        )
        
        patience_counter = 0
        patience = 10
        
        for epoch in range(freeze_epochs + 1, epochs + 1):
            train_loss, train_acc = self._train_epoch(train_loader, optimizer, criterion)
            val_loss, val_acc = self._val_epoch(val_loader, criterion)
            scheduler.step()
            
            self.history["train_loss"].append(train_loss)
            self.history["train_acc"].append(train_acc)
            self.history["val_loss"].append(val_loss)
            self.history["val_acc"].append(val_acc)
            
            logger.info(f"Epoch {epoch}/{epochs} | "
                       f"Train: {train_loss:.4f}/{train_acc:.2f}% | "
                       f"Val: {val_loss:.4f}/{val_acc:.2f}%")
            
            # Best model save karo
            if val_acc > best_val_acc:
                best_val_acc = val_acc
                self.save_model(save_path)
                logger.success(f"✅ Best model saved! Val Acc: {val_acc:.2f}%")
                patience_counter = 0
            else:
                patience_counter += 1
            
            # Early stopping
            if patience_counter >= patience:
                logger.info(f"Early stopping at epoch {epoch}")
                break
        
        logger.success(f"Training complete! Best Val Accuracy: {best_val_acc:.2f}%")
        self._save_history()
        return self.history

    def _train_epoch(self, loader, optimizer, criterion, scheduler=None):
        """Ek training epoch run karo"""
        self.model.train()
        total_loss = 0.0
        correct = 0
        total = 0
        
        for batch_idx, (images, labels) in enumerate(loader):
            images = images.to(self.device)
            labels = labels.to(self.device)
            
            optimizer.zero_grad()
            outputs = self.model(images)
            loss = criterion(outputs, labels)
            
            loss.backward()
            
            # Gradient clipping
            torch.nn.utils.clip_grad_norm_(self.model.parameters(), max_norm=1.0)
            
            optimizer.step()
            if scheduler is not None:
                scheduler.step()
            
            total_loss += loss.item()
            _, predicted = outputs.max(1)
            total += labels.size(0)
            correct += predicted.eq(labels).sum().item()
        
        avg_loss = total_loss / len(loader)
        accuracy = 100.0 * correct / total if total > 0 else 0
        return avg_loss, accuracy

    def _val_epoch(self, loader, criterion):
        """Validation epoch run karo"""
        self.model.eval()
        total_loss = 0.0
        correct = 0
        total = 0
        
        with torch.no_grad():
            for images, labels in loader:
                images = images.to(self.device)
                labels = labels.to(self.device)
                
                outputs = self.model(images)
                loss = criterion(outputs, labels)
                
                total_loss += loss.item()
                _, predicted = outputs.max(1)
                total += labels.size(0)
                correct += predicted.eq(labels).sum().item()
        
        avg_loss = total_loss / len(loader)
        accuracy = 100.0 * correct / total if total > 0 else 0
        return avg_loss, accuracy

    def save_model(self, path: str):
        """Model checkpoint save karo"""
        Path(path).parent.mkdir(parents=True, exist_ok=True)
        torch.save({
            "model_state_dict": self.model.state_dict(),
            "model_name": self.model.model_name,
            "num_classes": self.model.num_classes,
            "categories": PRODUCT_CATEGORIES,
            "history": self.history
        }, path)

    def _save_history(self):
        """Training history JSON mein save karo"""
        with open("models/training_history.json", "w") as f:
            json.dump(self.history, f, indent=2)


# ===================================================
# Inference Engine
# ===================================================
class ProductClassifier:
    """
    Trained CNN model se product classify karo
    Real-time inference ke liye optimized
    """

    def __init__(self, model_path: str = None,
                 categories: List[str] = None,
                 device: str = None):
        
        self.device = device or ("cuda" if torch.cuda.is_available() else "cpu")
        self.categories = categories or PRODUCT_CATEGORIES
        self.model = None
        self.transform = get_transforms("val")
        
        if model_path and Path(model_path).exists():
            self.load_model(model_path)
        else:
            # Demo mode - untrained model
            logger.warning("No trained model found. Loading untrained model for demo.")
            self.model = ProductClassifierModel(
                model_name="mobilenet_v3_small",
                num_classes=len(self.categories),
                pretrained=False
            ).to(self.device)
            self.model.eval()

    def load_model(self, path: str):
        """Saved model load karo"""
        try:
            checkpoint = torch.load(path, map_location=self.device)
            model_name = checkpoint.get("model_name", "mobilenet_v3_small")
            num_classes = checkpoint.get("num_classes", len(self.categories))
            
            if "categories" in checkpoint:
                self.categories = checkpoint["categories"]
            
            self.model = ProductClassifierModel(
                model_name=model_name,
                num_classes=num_classes,
                pretrained=False
            ).to(self.device)
            
            self.model.load_state_dict(checkpoint["model_state_dict"])
            self.model.eval()
            logger.success(f"✅ Model loaded: {path}")
            
        except Exception as e:
            logger.error(f"Model load failed: {e}")
            self.model = None

    def predict(self, image: np.ndarray, top_k: int = 3) -> List[Dict]:
        """
        Product classify karo
        
        Args:
            image: BGR numpy array (OpenCV format)
            top_k: Top-K predictions return karo
            
        Returns:
            List of dicts with category and confidence
        """
        if self.model is None:
            return [{"category": "Unknown", "confidence": 0.0, "rank": 1}]
        
        try:
            # BGR to PIL RGB convert karo
            image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
            pil_image = Image.fromarray(image_rgb)
            
            # Transform apply karo
            tensor = self.transform(pil_image).unsqueeze(0).to(self.device)
            
            # Inference
            with torch.no_grad():
                outputs = self.model(tensor)
                probabilities = torch.softmax(outputs, dim=1)[0]
            
            # Top-K results
            top_k_vals, top_k_indices = torch.topk(probabilities, min(top_k, len(self.categories)))
            
            results = []
            for rank, (val, idx) in enumerate(zip(top_k_vals.tolist(), top_k_indices.tolist()), 1):
                category = self.categories[idx] if idx < len(self.categories) else f"Class_{idx}"
                results.append({
                    "rank": rank,
                    "category": category,
                    "confidence": round(val, 4),
                    "confidence_pct": f"{val * 100:.1f}%"
                })
            
            return results
            
        except Exception as e:
            logger.error(f"Prediction error: {e}")
            return [{"category": "Error", "confidence": 0.0, "rank": 1}]

    def predict_batch(self, images: List[np.ndarray]) -> List[List[Dict]]:
        """Multiple images ek saath classify karo"""
        return [self.predict(img) for img in images]

    def get_feature_embeddings(self, image: np.ndarray) -> np.ndarray:
        """Feature embeddings extract karo (similarity search ke liye)"""
        if self.model is None:
            return np.zeros(512)
        
        image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
        pil_image = Image.fromarray(image_rgb)
        tensor = self.transform(pil_image).unsqueeze(0).to(self.device)
        
        with torch.no_grad():
            # Backbone features
            features = self.model.backbone(tensor)
        
        return features.cpu().numpy().flatten()
