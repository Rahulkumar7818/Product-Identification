"""
===================================================
app.py
Mall Product Identification System
Streamlit Web Application (Main UI)
===================================================
Run: streamlit run app.py
===================================================
"""

import streamlit as st
import cv2
import numpy as np
from PIL import Image
import io
import json
import time
import sys
from pathlib import Path

# Project imports
sys.path.insert(0, str(Path(__file__).parent))


# ─── Page Configuration ──────────────────────────────
st.set_page_config(
    page_title="🛍️ Mall Product Identifier",
    page_icon="🏬",
    layout="wide",
    initial_sidebar_state="expanded"
)

# ─── Custom CSS ──────────────────────────────────────
st.markdown("""
<style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');
    
    * { font-family: 'Inter', sans-serif; }
    
    .main { background: #0e1117; }
    
    .hero-title {
        font-size: 2.5rem; font-weight: 700;
        background: linear-gradient(135deg, #FFD700, #FFA500);
        -webkit-background-clip: text; -webkit-text-fill-color: transparent;
        text-align: center; margin-bottom: 0.5rem;
    }
    .hero-subtitle {
        text-align: center; color: #aaa; font-size: 1rem; margin-bottom: 2rem;
    }
    .result-card {
        background: linear-gradient(135deg, #1a1f2e, #161b27);
        border: 1px solid rgba(255,215,0,0.2);
        border-radius: 12px; padding: 20px; margin: 10px 0;
    }
    .metric-card {
        background: #1e2433; border-radius: 10px;
        padding: 15px; text-align: center;
        border: 1px solid rgba(255,255,255,0.05);
    }
    .metric-value { font-size: 1.8rem; font-weight: 700; color: #FFD700; }
    .metric-label { color: #888; font-size: 0.85rem; margin-top: 4px; }
    .badge {
        display: inline-block; padding: 3px 10px;
        border-radius: 20px; font-size: 0.75rem; font-weight: 600;
    }
    .badge-green { background: rgba(34,197,94,0.15); color: #22c55e; border: 1px solid rgba(34,197,94,0.3); }
    .badge-yellow { background: rgba(255,193,7,0.15); color: #ffc107; border: 1px solid rgba(255,193,7,0.3); }
    .badge-red { background: rgba(239,68,68,0.15); color: #ef4444; border: 1px solid rgba(239,68,68,0.3); }
    .badge-blue { background: rgba(59,130,246,0.15); color: #60a5fa; border: 1px solid rgba(59,130,246,0.3); }
    
    .floor-card {
        background: linear-gradient(135deg, rgba(34,197,94,0.1), rgba(34,197,94,0.03));
        border: 1px solid rgba(34,197,94,0.25); border-radius: 10px; padding: 15px;
    }
    
    /* Streamlit customizations */
    .stButton button {
        background: linear-gradient(135deg, #FFD700, #FFA500);
        color: #000; font-weight: 700; border: none;
        border-radius: 8px; width: 100%; padding: 12px;
    }
    .stButton button:hover { opacity: 0.9; }
    
    div[data-testid="stExpander"] {
        background: #1a1f2e; border: 1px solid rgba(255,255,255,0.1);
        border-radius: 10px;
    }
</style>
""", unsafe_allow_html=True)


# ─── Initialize Pipeline ─────────────────────────────
@st.cache_resource
def load_pipeline(enable_yolo: bool, enable_ocr: bool, enable_cnn: bool):
    """Pipeline load karo (cache karke fast reload)"""
    try:
        from src.pipeline import ProductIdentificationPipeline
        pipeline = ProductIdentificationPipeline(
            enable_yolo=enable_yolo,
            enable_ocr=enable_ocr,
            enable_cnn=enable_cnn
        )
        return pipeline, None
    except Exception as e:
        return None, str(e)


# ─── Sidebar ─────────────────────────────────────────
with st.sidebar:
    st.markdown("## ⚙️ Settings")
    
    st.markdown("### AI Modules")
    enable_yolo = st.toggle("🎯 YOLO Detection", value=True, help="Object detection")
    enable_cnn = st.toggle("🧠 CNN Classifier", value=True, help="Deep learning classification")
    enable_ocr = st.toggle("📝 OCR Engine", value=True, help="Text & barcode extraction")
    
    st.markdown("---")
    st.markdown("### About")
    st.info("""
    **Technology Stack**
    - 🎯 YOLOv8 - Object Detection
    - 🧠 MobileNetV3 - CNN Classification
    - 📝 EasyOCR - Text Recognition
    - 📊 SQLite - Product Database
    - 🔢 pyzbar - Barcode Reading
    """)
    
    st.markdown("---")
    st.markdown("### 🏬 Mall Floors")
    mall_floors = {
        "🟡 G Floor": "Fashion & Footwear (Zone A)",
        "🟠 1st Floor": "Electronics (Zone B)",
        "🔵 2nd Floor": "Jewellery & Beauty (Zone C)",
        "🟢 3rd Floor": "Sports & Home (Zone D)",
        "🔴 Food Court": "Food & Beverages (Zone E)",
    }
    for floor, desc in mall_floors.items():
        st.caption(f"**{floor}**: {desc}")


# ─── Main Content ─────────────────────────────────────
st.markdown('<div class="hero-title">🛍️ Mall Vision AI</div>', unsafe_allow_html=True)
st.markdown('<div class="hero-subtitle">Product Identification using YOLO • CNN • OCR • Deep Learning</div>', unsafe_allow_html=True)

# Load pipeline
pipeline, pipeline_error = load_pipeline(enable_yolo, enable_ocr, enable_cnn)

if pipeline_error:
    st.warning(f"⚠️ Pipeline partial load: {pipeline_error}")

# ─── Upload Section ────────────────────────────────────
st.markdown("### 📸 Upload Product Image")

upload_col, demo_col = st.columns([3, 1])

with upload_col:
    uploaded_file = st.file_uploader(
        "Product ki photo upload karo",
        type=["jpg", "jpeg", "png", "webp", "bmp"],
        help="Supported: JPG, PNG, WEBP, BMP — Max 10MB"
    )

with demo_col:
    st.markdown("**Demo:**")
    if st.button("🎲 Random Demo", help="Demo image use karo"):
        st.session_state["use_demo"] = True

# ─── Process Image ─────────────────────────────────────
image_to_process = None

if uploaded_file is not None:
    image_bytes = uploaded_file.read()
    image_to_process = image_bytes
    st.success(f"✅ Image uploaded: {uploaded_file.name} ({len(image_bytes)/1024:.1f} KB)")

if image_to_process is not None:
    # Show image
    nparr = np.frombuffer(image_to_process, np.uint8)
    cv_image = cv2.imdecode(nparr, cv2.IMREAD_COLOR)
    
    col1, col2 = st.columns([1, 1])
    
    with col1:
        st.markdown("**📷 Input Image**")
        st.image(
            cv2.cvtColor(cv_image, cv2.COLOR_BGR2RGB),
            use_column_width=True
        )
        
        h, w = cv_image.shape[:2]
        st.caption(f"Dimensions: {w}×{h} pixels | Channels: {cv_image.shape[2]}")

    # ─── Identify Button ───────────────────────────────
    identify_btn = st.button("🔍 Product Identify Karo!", use_container_width=True)
    
    if identify_btn:
        if pipeline is None:
            # Fallback - use database only
            st.info("Full AI pipeline nahi chala, database mode mein chal raha hai...")
            
            from src.product_database import ProductDatabase, MALL_LAYOUT
            db = ProductDatabase()
            
            result_data = {
                "processing_time": 0.1,
                "yolo_objects_detected": 0,
                "primary_category": "Electronics",
                "category_confidence": 0.75,
                "cnn_predictions": [{"rank": 1, "category": "Electronics", "confidence_pct": "75.0%"}],
                "ocr_text": "Demo mode - Upload real image with full pipeline",
                "detected_prices": [],
                "detected_brands": [],
                "barcodes": [],
                "db_matches": db.search_by_category("Electronics"),
                "mall_location": db.get_mall_location("Electronics"),
                "product_name": "Demo Product",
                "confidence_level": "Medium",
                "summary": "Demo mode - Install all requirements for full functionality",
            }
            annotated = cv_image.copy()
            
        else:
            with st.spinner("🤖 AI analysis chal raha hai..."):
                progress = st.progress(0, "Initializing...")
                
                progress.progress(20, "🎯 YOLO Detection...")
                time.sleep(0.2)
                
                progress.progress(50, "🧠 CNN Classification...")
                result = pipeline.identify(cv_image)
                
                progress.progress(80, "📝 OCR Processing...")
                time.sleep(0.2)
                
                progress.progress(100, "✅ Done!")
                time.sleep(0.3)
                progress.empty()
                
                result_data = result.to_dict()
                annotated = result.yolo_annotated_image if result.yolo_annotated_image is not None else cv_image
        
        st.markdown("---")
        st.markdown("## 🎯 Identification Results")
        
        # ─── Quick Metrics Row ─────────────────────────────
        m1, m2, m3, m4 = st.columns(4)
        with m1:
            st.markdown(f"""
            <div class="metric-card">
                <div class="metric-value">{result_data.get('yolo_objects_detected', 0)}</div>
                <div class="metric-label">Objects Detected (YOLO)</div>
            </div>""", unsafe_allow_html=True)
        with m2:
            conf = result_data.get('category_confidence', 0)
            st.markdown(f"""
            <div class="metric-card">
                <div class="metric-value">{conf*100:.0f}%</div>
                <div class="metric-label">CNN Confidence</div>
            </div>""", unsafe_allow_html=True)
        with m3:
            prices = result_data.get('detected_prices', [])
            price_display = prices[0] if prices else "N/A"
            st.markdown(f"""
            <div class="metric-card">
                <div class="metric-value" style="font-size:1.3rem">{price_display}</div>
                <div class="metric-label">Detected Price</div>
            </div>""", unsafe_allow_html=True)
        with m4:
            proc_time = result_data.get('processing_time', 0)
            st.markdown(f"""
            <div class="metric-card">
                <div class="metric-value">{proc_time:.2f}s</div>
                <div class="metric-label">Processing Time</div>
            </div>""", unsafe_allow_html=True)
        
        st.markdown("<br>", unsafe_allow_html=True)
        
        # ─── Main Results ────────────────────────────────────
        res_col1, res_col2 = st.columns([1, 1])
        
        with res_col1:
            # Annotated image
            st.markdown("**🎯 YOLO Detection Output**")
            st.image(cv2.cvtColor(annotated, cv2.COLOR_BGR2RGB), use_column_width=True)
            
            # CNN Predictions
            st.markdown("**🧠 CNN Classification (Top 5)**")
            predictions = result_data.get("cnn_predictions", [])
            if predictions:
                for pred in predictions[:5]:
                    cat = pred.get("category", "Unknown")
                    conf_pct = pred.get("confidence_pct", "0%")
                    rank = pred.get("rank", 1)
                    
                    conf_val = float(conf_pct.replace("%", "")) / 100
                    bar_color = "#22c55e" if rank == 1 else "#60a5fa" if rank <= 3 else "#6b7280"
                    
                    st.markdown(f"""
                    <div style="margin:5px 0; padding:8px 12px; background:#1e2433; border-radius:8px;
                                border-left: 3px solid {bar_color};">
                        <span style="color:#ddd; font-size:0.85rem;">#{rank} {cat}</span>
                        <span style="float:right; color:{bar_color}; font-weight:600;">{conf_pct}</span>
                    </div>""", unsafe_allow_html=True)
                    
                    st.progress(conf_val)
            else:
                st.info("CNN predictions available nahi hain")
        
        with res_col2:
            # Product Info Card
            product_name = result_data.get("product_name", "Unknown")
            category = result_data.get("primary_category", "Unknown")
            conf_level = result_data.get("confidence_level", "Low")
            
            badge_class = "badge-green" if conf_level in ["Very High", "High"] else "badge-yellow" if conf_level == "Medium" else "badge-red"
            
            st.markdown(f"""
            <div class="result-card">
                <h3 style="color:#FFD700; margin:0 0 8px;">🛍️ {product_name}</h3>
                <div style="margin-bottom:12px;">
                    <span class="badge badge-blue">📦 {category}</span>
                    &nbsp;
                    <span class="badge {badge_class}">Confidence: {conf_level}</span>
                </div>
                <p style="color:#aaa; font-size:0.9rem; margin:0;">
                    {result_data.get('summary', '')}
                </p>
            </div>""", unsafe_allow_html=True)
            
            # Mall Location Card
            location = result_data.get("mall_location", {})
            floor = location.get("floor", "Unknown")
            zone = location.get("zone", "?")
            stores = location.get("stores", [])
            
            st.markdown(f"""
            <div class="floor-card">
                <h4 style="color:#22c55e; margin:0 0 10px;">🏬 Mall Location</h4>
                <div style="display:flex; gap:15px; margin-bottom:10px;">
                    <div style="text-align:center; background:rgba(34,197,94,0.1); padding:10px 20px; border-radius:8px; flex:1;">
                        <div style="color:#22c55e; font-size:1.2rem; font-weight:700;">{floor}</div>
                        <div style="color:#888; font-size:0.75rem;">Floor</div>
                    </div>
                    <div style="text-align:center; background:rgba(34,197,94,0.1); padding:10px 20px; border-radius:8px;">
                        <div style="color:#22c55e; font-size:1.5rem; font-weight:700;">Zone {zone}</div>
                        <div style="color:#888; font-size:0.75rem;">Zone</div>
                    </div>
                </div>
                <div style="color:#86efac; font-size:0.8rem; margin-bottom:5px;">🏪 Available Stores:</div>
                <div>{"".join(f'<span class="badge badge-green" style="margin:2px;">{s}</span>' for s in stores[:5]) or "Search at Information Desk"}</div>
            </div>""", unsafe_allow_html=True)
            
            # OCR Results
            ocr_text = result_data.get("ocr_text", "")
            brands = result_data.get("detected_brands", [])
            barcodes = result_data.get("barcodes", [])
            
            with st.expander("📝 OCR Text Extraction", expanded=True):
                if ocr_text:
                    st.code(ocr_text[:500], language=None)
                else:
                    st.info("OCR text nahi mila (low quality image ya text nahi hai)")
                
                if brands:
                    st.markdown(f"**Brands detected:** {', '.join(brands)}")
                
                if barcodes:
                    for bc in barcodes:
                        st.success(f"🔢 Barcode ({bc.get('type')}): `{bc.get('data')}`")
            
            # DB Matches
            db_matches = result_data.get("db_matches", [])
            if db_matches:
                with st.expander(f"🗄️ Database Matches ({len(db_matches)} found)", expanded=True):
                    for match in db_matches[:3]:
                        price_range = ""
                        if match.get("price_min") and match.get("price_max"):
                            price_range = f"₹{match['price_min']:,.0f} - ₹{match['price_max']:,.0f}"
                        
                        st.markdown(f"""
                        <div style="background:#1e2433; padding:12px; border-radius:8px; margin:5px 0; border-left:3px solid #FFD700;">
                            <strong style="color:#FFD700;">{match.get('brand', '')} {match.get('name', '')}</strong><br>
                            <span style="color:#aaa; font-size:0.85rem;">{match.get('category')} | {price_range}</span><br>
                            <span style="color:#888; font-size:0.8rem;">{match.get('description', '')}</span>
                        </div>""", unsafe_allow_html=True)
        
        # ─── Raw JSON Data ────────────────────────────────────
        with st.expander("🔧 Raw JSON Output (Developer Mode)"):
            st.json(result_data)


# ─── Mall Map Section ─────────────────────────────────
st.markdown("---")
st.markdown("## 🗺️ Mall Floor Map")

floor_cols = st.columns(5)
floor_data = [
    ("🟡", "Ground Floor", "Zone A", ["H&M", "Zara", "Nike", "Adidas"], "#FFD700"),
    ("🟠", "1st Floor", "Zone B", ["Apple", "Samsung", "Croma", "Dell"], "#FFA500"),
    ("🔵", "2nd Floor", "Zone C", ["Titan", "Tanishq", "MAC", "Nykaa"], "#60a5fa"),
    ("🟢", "3rd Floor", "Zone D", ["Decathlon", "Hamleys", "LG", "Prestige"], "#22c55e"),
    ("🔴", "Food Court", "Zone E", ["McDonald's", "KFC", "Starbucks", "Subway"], "#ef4444"),
]

for col, (emoji, floor, zone, stores, color) in zip(floor_cols, floor_data):
    with col:
        stores_html = "".join(f'<div style="color:#aaa;font-size:0.75rem;padding:2px 0;">• {s}</div>' for s in stores)
        st.markdown(f"""
        <div style="background:#1a1f2e; border:1px solid {color}33; border-top:3px solid {color}; 
                    border-radius:10px; padding:15px; text-align:center; height:220px;">
            <div style="font-size:2rem;">{emoji}</div>
            <div style="color:{color}; font-weight:700; font-size:0.9rem; margin:5px 0;">{floor}</div>
            <div style="color:#888; font-size:0.75rem; margin-bottom:8px;">{zone}</div>
            {stores_html}
        </div>""", unsafe_allow_html=True)

# ─── Footer ───────────────────────────────────────────
st.markdown("---")
st.markdown("""
<div style="text-align:center; color:#555; font-size:0.85rem; padding:20px 0;">
    🛍️ Mall Product Identification System | 
    YOLOv8 + MobileNetV3 + EasyOCR + SQLite |
    Built with Python & Streamlit
</div>
""", unsafe_allow_html=True)
