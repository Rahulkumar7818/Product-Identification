"""
===================================================
src/yolo_detector.py
Mall Product Identification System
YOLO-based Product Detection Module
===================================================
Ye module YOLOv8 use karke products ko image mein
detect karta hai aur bounding boxes return karta hai.
===================================================
"""

import cv2
import numpy as np
from pathlib import Path
from typing import List, Dict, Tuple, Optional
from loguru import logger
from dataclasses import dataclass


@dataclass
class Detection:
    """Ek detected product ki information"""
    bbox: Tuple[int, int, int, int]   # (x1, y1, x2, y2)
    confidence: float
    class_id: int
    class_name: str
    cropped_image: Optional[np.ndarray] = None


class YOLODetector:
    """
    YOLOv8-based Product Detector
    
    Features:
    - Pre-trained COCO weights se start
    - Custom mall product dataset pe fine-tune
    - Real-time detection support
    - Multiple product detection in single image
    """

    # COCO classes jo mall mein relevant hain
    MALL_RELEVANT_CLASSES = {
        63: "laptop",
        64: "mouse",
        65: "remote",
        66: "keyboard",
        67: "cell phone",
        73: "book",
        74: "clock",
        76: "scissors",
        77: "teddy bear",
        78: "hair drier",
        79: "toothbrush",
        39: "bottle",
        41: "cup",
        42: "fork",
        43: "knife",
        46: "wine glass",
        47: "cup",
        25: "umbrella",
        26: "handbag",
        27: "tie",
        28: "suitcase",
    }

    def __init__(self, model_path: str = "yolov8n.pt",
                 confidence: float = 0.45,
                 iou_threshold: float = 0.45,
                 device: str = "cpu"):
        """
        YOLODetector initialize karo
        
        Args:
            model_path: YOLOv8 model file path
            confidence: Minimum detection confidence (0-1)
            iou_threshold: IoU threshold for NMS
            device: 'cpu', 'cuda', or 'mps'
        """
        self.model_path = model_path
        self.confidence = confidence
        self.iou_threshold = iou_threshold
        self.device = device
        self.model = None
        self._load_model()

    def _load_model(self):
        """YOLOv8 model load karo"""
        try:
            from ultralytics import YOLO
            logger.info(f"Loading YOLO model: {self.model_path}")
            self.model = YOLO(self.model_path)
            logger.success("✅ YOLO model loaded successfully!")
        except ImportError:
            logger.error("ultralytics package install karo: pip install ultralytics")
            raise
        except Exception as e:
            logger.error(f"Model loading failed: {e}")
            raise

    def detect(self, image: np.ndarray) -> List[Detection]:
        """
        Image mein products detect karo
        
        Args:
            image: BGR format numpy array (OpenCV image)
            
        Returns:
            List of Detection objects
        """
        if self.model is None:
            raise RuntimeError("Model load nahi hua!")

        detections = []
        
        try:
            # RGB convert karo (YOLO ko RGB chahiye)
            image_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
            
            # YOLO inference run karo
            results = self.model(
                image_rgb,
                conf=self.confidence,
                iou=self.iou_threshold,
                device=self.device,
                verbose=False
            )
            
            # Results parse karo
            for result in results:
                boxes = result.boxes
                if boxes is None:
                    continue
                    
                for box in boxes:
                    # Bounding box coordinates
                    x1, y1, x2, y2 = map(int, box.xyxy[0].tolist())
                    conf = float(box.conf[0])
                    cls_id = int(box.cls[0])
                    
                    # Class name get karo
                    if self.model.names and cls_id in self.model.names:
                        cls_name = self.model.names[cls_id]
                    else:
                        cls_name = f"Class_{cls_id}"
                    
                    # Cropped image extract karo
                    h, w = image.shape[:2]
                    x1_c = max(0, x1)
                    y1_c = max(0, y1)
                    x2_c = min(w, x2)
                    y2_c = min(h, y2)
                    cropped = image[y1_c:y2_c, x1_c:x2_c].copy()
                    
                    detection = Detection(
                        bbox=(x1, y1, x2, y2),
                        confidence=conf,
                        class_id=cls_id,
                        class_name=cls_name,
                        cropped_image=cropped
                    )
                    detections.append(detection)
            
            logger.info(f"Detected {len(detections)} objects")
            return detections
            
        except Exception as e:
            logger.error(f"Detection error: {e}")
            return []

    def draw_detections(self, image: np.ndarray,
                        detections: List[Detection],
                        color: Tuple = (0, 255, 0)) -> np.ndarray:
        """
        Detected objects ko image pe draw karo
        
        Args:
            image: Original image
            detections: List of Detection objects
            color: Bounding box color (BGR)
            
        Returns:
            Annotated image
        """
        annotated = image.copy()
        
        # Color palette for different classes
        colors = [
            (255, 50, 50),   # Red
            (50, 255, 50),   # Green
            (50, 50, 255),   # Blue
            (255, 255, 50),  # Yellow
            (255, 50, 255),  # Magenta
            (50, 255, 255),  # Cyan
            (255, 165, 0),   # Orange
            (148, 0, 211),   # Violet
        ]
        
        for i, det in enumerate(detections):
            x1, y1, x2, y2 = det.bbox
            box_color = colors[det.class_id % len(colors)]
            
            # Bounding box draw karo
            cv2.rectangle(annotated, (x1, y1), (x2, y2), box_color, 2)
            
            # Label background
            label = f"{det.class_name} {det.confidence:.2f}"
            (label_w, label_h), _ = cv2.getTextSize(label, cv2.FONT_HERSHEY_SIMPLEX, 0.6, 2)
            cv2.rectangle(annotated, (x1, y1 - label_h - 10), (x1 + label_w + 10, y1), box_color, -1)
            
            # Label text
            cv2.putText(annotated, label, (x1 + 5, y1 - 5),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 2)
        
        return annotated

    def detect_from_path(self, image_path: str) -> Tuple[np.ndarray, List[Detection]]:
        """
        Image file path se detect karo
        
        Args:
            image_path: Image file ka path
            
        Returns:
            Tuple of (original_image, detections)
        """
        image = cv2.imread(image_path)
        if image is None:
            raise FileNotFoundError(f"Image nahi mila: {image_path}")
        
        detections = self.detect(image)
        return image, detections

    def get_detection_stats(self, detections: List[Detection]) -> Dict:
        """Detection statistics generate karo"""
        if not detections:
            return {"total": 0, "classes": {}, "avg_confidence": 0}
        
        class_counts = {}
        for det in detections:
            class_counts[det.class_name] = class_counts.get(det.class_name, 0) + 1
        
        avg_conf = sum(d.confidence for d in detections) / len(detections)
        
        return {
            "total": len(detections),
            "classes": class_counts,
            "avg_confidence": round(avg_conf, 3),
            "top_class": max(class_counts, key=class_counts.get)
        }


class CustomYOLOTrainer:
    """
    Custom YOLO training for mall products.
    Apna dataset pe fine-tune karo.
    """
    
    def __init__(self, base_model: str = "yolov8n.pt"):
        self.base_model = base_model
    
    def prepare_dataset_yaml(self, train_path: str, val_path: str,
                              classes: List[str], save_path: str = "config/dataset.yaml"):
        """YOLO dataset YAML file banao"""
        yaml_content = f"""# Mall Product Detection Dataset
path: .
train: {train_path}
val: {val_path}

nc: {len(classes)}  # number of classes
names: {classes}
"""
        Path(save_path).parent.mkdir(parents=True, exist_ok=True)
        with open(save_path, 'w') as f:
            f.write(yaml_content)
        logger.info(f"Dataset YAML saved: {save_path}")
        return save_path
    
    def train(self, data_yaml: str, epochs: int = 50,
              img_size: int = 640, batch: int = 16,
              save_dir: str = "models/"):
        """
        Custom dataset pe YOLO train karo
        
        Args:
            data_yaml: Dataset configuration YAML path
            epochs: Training epochs
            img_size: Input image size
            batch: Batch size
            save_dir: Model save directory
        """
        try:
            from ultralytics import YOLO
            model = YOLO(self.base_model)
            
            logger.info(f"Training started: {epochs} epochs")
            results = model.train(
                data=data_yaml,
                epochs=epochs,
                imgsz=img_size,
                batch=batch,
                project=save_dir,
                name="product_detection",
                pretrained=True,
                optimizer="AdamW",
                lr0=0.001,
                momentum=0.937,
                weight_decay=0.0005,
                warmup_epochs=3,
                patience=10,
                save=True,
                device="cpu"
            )
            
            logger.success(f"✅ Training complete! Results: {results}")
            return results
            
        except Exception as e:
            logger.error(f"Training failed: {e}")
            raise
    
    def validate(self, model_path: str, data_yaml: str):
        """Trained model validate karo"""
        from ultralytics import YOLO
        model = YOLO(model_path)
        metrics = model.val(data=data_yaml)
        logger.info(f"Validation mAP50: {metrics.box.map50:.4f}")
        return metrics
    
    def export_model(self, model_path: str, format: str = "onnx"):
        """
        Model export karo deployment ke liye
        Formats: onnx, tflite, torchscript, coreml
        """
        from ultralytics import YOLO
        model = YOLO(model_path)
        model.export(format=format)
        logger.success(f"Model exported as {format}")
