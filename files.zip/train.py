"""
===================================================
train.py
Mall Product Identification System
Model Training Script
===================================================
CNN aur YOLO dono train karne ke liye use karo.

Usage:
    python train.py --model cnn --epochs 50
    python train.py --model yolo --epochs 100
    python train.py --model both
===================================================
"""

import argparse
import sys
import torch
from pathlib import Path
from loguru import logger
from rich.console import Console
from rich.table import Table
from rich.progress import Progress, SpinnerColumn, TimeElapsedColumn
import json

console = Console()


def train_cnn(args):
    """CNN Model Training"""
    console.print("\n[bold yellow]🧠 CNN Model Training Started[/bold yellow]")
    console.print(f"  Model: {args.cnn_model}")
    console.print(f"  Epochs: {args.epochs}")
    console.print(f"  Batch Size: {args.batch_size}")
    console.print(f"  Learning Rate: {args.lr}")
    console.print(f"  Data Dir: {args.data_dir}")
    
    from src.cnn_classifier import CNNTrainer
    
    trainer = CNNTrainer(
        model_name=args.cnn_model,
        device=args.device
    )
    
    history = trainer.train(
        data_dir=args.data_dir,
        epochs=args.epochs,
        batch_size=args.batch_size,
        lr=args.lr,
        save_path=f"models/{args.cnn_model}_classifier.pth",
        freeze_epochs=args.freeze_epochs
    )
    
    if history:
        # Final results print karo
        table = Table(title="Training Results")
        table.add_column("Metric", style="cyan")
        table.add_column("Best Value", style="green")
        
        if history.get("val_acc"):
            best_val_acc = max(history["val_acc"])
            best_epoch = history["val_acc"].index(best_val_acc) + 1
            table.add_row("Best Val Accuracy", f"{best_val_acc:.2f}%")
            table.add_row("Best Epoch", str(best_epoch))
        
        if history.get("val_loss"):
            best_val_loss = min(history["val_loss"])
            table.add_row("Best Val Loss", f"{best_val_loss:.4f}")
        
        console.print(table)
        console.print(f"\n[bold green]✅ CNN Model saved: models/{args.cnn_model}_classifier.pth[/bold green]")
    
    return history


def train_yolo(args):
    """YOLO Model Training"""
    console.print("\n[bold yellow]🎯 YOLO Model Training Started[/bold yellow]")
    
    # Dataset YAML check karo
    dataset_yaml = Path(args.data_dir) / "dataset.yaml"
    if not dataset_yaml.exists():
        console.print("[red]❌ dataset.yaml nahi mila![/red]")
        console.print("YOLO dataset structure needed:")
        console.print("""
  data/
    dataset.yaml
    train/
      images/  ← training images
      labels/  ← YOLO format labels (.txt)
    val/
      images/
      labels/
        """)
        
        # Sample YAML create karo
        sample_yaml = f"""# YOLO Dataset Configuration
path: {Path(args.data_dir).absolute()}
train: train/images
val: val/images

nc: 20  # number of classes
names: ['Electronics', 'Mobile_Phones', 'Laptops', 'Headphones',
        'Clothing_Men', 'Clothing_Women', 'Footwear', 'Bags',
        'Watches', 'Jewellery', 'Food', 'Beverages',
        'Cosmetics', 'Toys', 'Books', 'Sports',
        'Appliances', 'Kitchen', 'Medicine', 'Others']
"""
        dataset_yaml.parent.mkdir(parents=True, exist_ok=True)
        with open(dataset_yaml, 'w') as f:
            f.write(sample_yaml)
        console.print(f"[yellow]Sample dataset.yaml created: {dataset_yaml}[/yellow]")
        console.print("[yellow]Please add your images and labels, then run again.[/yellow]")
        return None
    
    from src.yolo_detector import CustomYOLOTrainer
    
    trainer = CustomYOLOTrainer(base_model=args.yolo_model)
    results = trainer.train(
        data_yaml=str(dataset_yaml),
        epochs=args.epochs,
        img_size=args.img_size,
        batch=args.batch_size,
        save_dir="models/"
    )
    
    console.print("[bold green]✅ YOLO training complete![/bold green]")
    return results


def evaluate_models(args):
    """Trained models evaluate karo"""
    console.print("\n[bold cyan]📊 Model Evaluation[/bold cyan]")
    
    # CNN Evaluation
    cnn_model_path = f"models/{args.cnn_model}_classifier.pth"
    if Path(cnn_model_path).exists():
        from src.cnn_classifier import ProductClassifier, ProductDataset, get_transforms
        from torch.utils.data import DataLoader
        import torch
        
        classifier = ProductClassifier(model_path=cnn_model_path)
        
        test_dataset = ProductDataset(args.data_dir, get_transforms("val"), "test")
        if len(test_dataset) > 0:
            test_loader = DataLoader(test_dataset, batch_size=32)
            
            correct = 0
            total = 0
            classifier.model.eval()
            
            with torch.no_grad():
                for images, labels in test_loader:
                    images = images.to(classifier.device)
                    labels = labels.to(classifier.device)
                    outputs = classifier.model(images)
                    _, predicted = outputs.max(1)
                    total += labels.size(0)
                    correct += predicted.eq(labels).sum().item()
            
            acc = 100.0 * correct / total
            console.print(f"  CNN Test Accuracy: [green]{acc:.2f}%[/green] ({correct}/{total})")
        else:
            console.print("  Test dataset nahi mila")
    else:
        console.print(f"  [yellow]CNN model nahi mila: {cnn_model_path}[/yellow]")


def demo_inference(args):
    """Demo inference run karo"""
    console.print("\n[bold magenta]🚀 Demo Inference[/bold magenta]")
    
    # Sample image dhundho
    sample_dir = Path("data/sample_images")
    sample_images = list(sample_dir.glob("*.jpg")) + list(sample_dir.glob("*.png"))
    
    if not sample_images:
        console.print("[yellow]Koi sample image nahi mila.[/yellow]")
        console.print("data/sample_images/ mein koi image daalo aur dobara run karo.")
        return
    
    from src.pipeline import ProductIdentificationPipeline
    
    pipeline = ProductIdentificationPipeline(
        enable_yolo=True,
        enable_ocr=True,
        enable_cnn=True
    )
    
    for img_path in sample_images[:3]:
        console.print(f"\nProcessing: {img_path.name}")
        
        try:
            result = pipeline.identify_from_path(str(img_path))
            
            table = Table(title=f"Result: {img_path.name}")
            table.add_column("Field", style="cyan")
            table.add_column("Value", style="white")
            
            table.add_row("Product", result.product_name)
            table.add_row("Category", result.primary_category)
            table.add_row("Confidence", f"{result.category_confidence:.2%}")
            table.add_row("Floor", result.mall_location.get("floor", "Unknown"))
            table.add_row("Zone", result.mall_location.get("zone", "?"))
            table.add_row("OCR Text", result.ocr_text[:80] or "N/A")
            table.add_row("Prices", str(result.detected_prices or "None"))
            table.add_row("Processing Time", f"{result.processing_time:.3f}s")
            
            console.print(table)
            
        except Exception as e:
            console.print(f"[red]Error: {e}[/red]")


def main():
    parser = argparse.ArgumentParser(
        description="Mall Product Identification - Training Script",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  python train.py --mode train_cnn --epochs 50
  python train.py --mode train_yolo --epochs 100
  python train.py --mode both --epochs 50
  python train.py --mode evaluate
  python train.py --mode demo
        """
    )
    
    parser.add_argument("--mode", choices=["train_cnn", "train_yolo", "both", "evaluate", "demo"],
                        default="demo", help="Kya karna hai")
    parser.add_argument("--epochs", type=int, default=50, help="Training epochs")
    parser.add_argument("--batch_size", type=int, default=32, help="Batch size")
    parser.add_argument("--lr", type=float, default=0.001, help="Learning rate")
    parser.add_argument("--freeze_epochs", type=int, default=5, help="Backbone freeze epochs")
    parser.add_argument("--img_size", type=int, default=640, help="YOLO image size")
    parser.add_argument("--cnn_model", default="mobilenet_v3_small",
                        choices=["mobilenet_v3_small", "resnet50", "efficientnet_b0"],
                        help="CNN model architecture")
    parser.add_argument("--yolo_model", default="yolov8n.pt", help="YOLO base model")
    parser.add_argument("--data_dir", default="data/dataset", help="Dataset directory")
    parser.add_argument("--device", default="cpu", choices=["cpu", "cuda", "mps"], help="Training device")
    
    args = parser.parse_args()
    
    # GPU check karo
    if args.device == "cuda" and not torch.cuda.is_available():
        console.print("[yellow]⚠️ CUDA nahi mila, CPU use ho raha hai[/yellow]")
        args.device = "cpu"
    
    console.print(f"\n[bold]Mall Product Identification System - Training[/bold]")
    console.print(f"Mode: [cyan]{args.mode}[/cyan] | Device: [cyan]{args.device}[/cyan]")
    
    if args.mode == "train_cnn":
        train_cnn(args)
    elif args.mode == "train_yolo":
        train_yolo(args)
    elif args.mode == "both":
        train_cnn(args)
        train_yolo(args)
    elif args.mode == "evaluate":
        evaluate_models(args)
    elif args.mode == "demo":
        demo_inference(args)
    
    console.print("\n[bold green]✅ Done![/bold green]")


if __name__ == "__main__":
    main()
