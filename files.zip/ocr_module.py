"""
===================================================
src/ocr_module.py
Mall Product Identification System
OCR & Barcode Reading Module
===================================================
Ye module EasyOCR + Tesseract use karke:
- Product labels se text extract karta hai
- Barcodes/QR codes read karta hai  
- Price tags recognize karta hai
- Brand names detect karta hai
===================================================
"""

import cv2
import numpy as np
import re
from typing import List, Dict, Optional, Tuple
from dataclasses import dataclass
from loguru import logger


@dataclass
class OCRResult:
    """OCR se extracted text ki information"""
    text: str
    confidence: float
    bbox: Optional[Tuple] = None
    text_type: str = "general"  # general, price, brand, barcode, qr


@dataclass
class BarcodeResult:
    """Barcode/QR reading result"""
    data: str
    barcode_type: str   # CODE128, EAN13, QR, etc.
    bbox: Optional[Tuple] = None


class OCREngine:
    """
    Multi-engine OCR System
    
    Features:
    - EasyOCR for natural scene text
    - Tesseract for clean document text
    - Barcode & QR code reading (pyzbar)
    - Price extraction with regex
    - Brand name detection
    - Hindi + English support
    """

    # Price patterns (Indian + International)
    PRICE_PATTERNS = [
        r'₹\s*[\d,]+(?:\.\d{2})?',          # ₹499, ₹1,299.00
        r'Rs\.?\s*[\d,]+(?:\.\d{2})?',       # Rs. 499, Rs499
        r'MRP\s*:?\s*₹?\s*[\d,]+',           # MRP: 499
        r'\$\s*[\d,]+(?:\.\d{2})?',          # $29.99
        r'Price\s*:?\s*₹?\s*[\d,]+',         # Price: 299
    ]

    # Common brand patterns to look for
    BRAND_KEYWORDS = [
        "brand", "by", "from", "made by", "product of"
    ]

    def __init__(self, use_easyocr: bool = True,
                 use_tesseract: bool = False,
                 languages: List[str] = None,
                 gpu: bool = False):
        """
        OCREngine initialize karo
        
        Args:
            use_easyocr: EasyOCR use karo
            use_tesseract: Tesseract use karo
            languages: OCR languages list
            gpu: GPU use karo ya nahi
        """
        self.use_easyocr = use_easyocr
        self.use_tesseract = use_tesseract
        self.languages = languages or ["en"]
        self.gpu = gpu
        self.easyocr_reader = None
        
        self._initialize_engines()

    def _initialize_engines(self):
        """OCR engines initialize karo"""
        if self.use_easyocr:
            try:
                import easyocr
                logger.info("EasyOCR initialize ho raha hai...")
                self.easyocr_reader = easyocr.Reader(
                    self.languages, gpu=self.gpu
                )
                logger.success("✅ EasyOCR ready!")
            except ImportError:
                logger.warning("EasyOCR not installed: pip install easyocr")
                self.use_easyocr = False
            except Exception as e:
                logger.error(f"EasyOCR init error: {e}")
                self.use_easyocr = False

        if self.use_tesseract:
            try:
                import pytesseract
                pytesseract.get_tesseract_version()
                logger.success("✅ Tesseract ready!")
            except Exception as e:
                logger.warning(f"Tesseract not available: {e}")
                self.use_tesseract = False

    def preprocess_image(self, image: np.ndarray) -> np.ndarray:
        """
        OCR ke liye image preprocess karo
        Better text recognition ke liye image enhance karo
        """
        # Grayscale convert karo
        if len(image.shape) == 3:
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        else:
            gray = image.copy()
        
        # Noise reduce karo
        denoised = cv2.fastNlMeansDenoising(gray, h=10)
        
        # Contrast enhance karo (CLAHE)
        clahe = cv2.createCLAHE(clipLimit=2.0, tileGridSize=(8, 8))
        enhanced = clahe.apply(denoised)
        
        # Sharpening kernel
        kernel = np.array([[0, -1, 0], [-1, 5, -1], [0, -1, 0]])
        sharpened = cv2.filter2D(enhanced, -1, kernel)
        
        # Adaptive thresholding for better contrast
        thresh = cv2.adaptiveThreshold(
            sharpened, 255,
            cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
            cv2.THRESH_BINARY, 11, 2
        )
        
        # Scale up if image is too small
        h, w = thresh.shape
        if h < 100 or w < 100:
            scale = max(100 / h, 100 / w, 2.0)
            thresh = cv2.resize(thresh, None, fx=scale, fy=scale,
                               interpolation=cv2.INTER_CUBIC)
        
        return thresh

    def extract_text_easyocr(self, image: np.ndarray,
                              preprocess: bool = True) -> List[OCRResult]:
        """
        EasyOCR se text extract karo
        
        Args:
            image: Input image (BGR format)
            preprocess: Image preprocess karo ya nahi
            
        Returns:
            List of OCRResult objects
        """
        if not self.use_easyocr or self.easyocr_reader is None:
            logger.warning("EasyOCR available nahi")
            return []
        
        results = []
        
        try:
            if preprocess:
                proc_image = self.preprocess_image(image)
            else:
                proc_image = image
            
            # EasyOCR se text read karo
            raw_results = self.easyocr_reader.readtext(proc_image)
            
            for (bbox_pts, text, confidence) in raw_results:
                if confidence < 0.3:  # Low confidence skip karo
                    continue
                
                text = text.strip()
                if not text:
                    continue
                
                # Determine text type
                text_type = self._classify_text(text)
                
                result = OCRResult(
                    text=text,
                    confidence=confidence,
                    bbox=tuple(map(tuple, bbox_pts)),
                    text_type=text_type
                )
                results.append(result)
            
            logger.info(f"EasyOCR: {len(results)} text regions found")
            return results
            
        except Exception as e:
            logger.error(f"EasyOCR error: {e}")
            return []

    def extract_text_tesseract(self, image: np.ndarray,
                                config: str = "--oem 3 --psm 6") -> List[OCRResult]:
        """
        Tesseract se text extract karo
        
        Args:
            image: Input image
            config: Tesseract config string
            
        Returns:
            List of OCRResult
        """
        if not self.use_tesseract:
            return []
        
        try:
            import pytesseract
            
            proc_image = self.preprocess_image(image)
            
            # Detailed output with confidence scores
            data = pytesseract.image_to_data(
                proc_image,
                output_type=pytesseract.Output.DICT,
                config=config
            )
            
            results = []
            for i, text in enumerate(data['text']):
                text = text.strip()
                if not text:
                    continue
                
                conf = float(data['conf'][i])
                if conf < 30:  # 30% confidence minimum
                    continue
                
                results.append(OCRResult(
                    text=text,
                    confidence=conf / 100.0,
                    text_type=self._classify_text(text)
                ))
            
            logger.info(f"Tesseract: {len(results)} words found")
            return results
            
        except Exception as e:
            logger.error(f"Tesseract error: {e}")
            return []

    def read_barcodes(self, image: np.ndarray) -> List[BarcodeResult]:
        """
        Image mein barcodes/QR codes read karo
        
        Args:
            image: Input image
            
        Returns:
            List of BarcodeResult objects
        """
        results = []
        
        try:
            from pyzbar.pyzbar import decode as pyzbar_decode
            from pyzbar.pyzbar import ZBarSymbol
            
            # Grayscale convert
            if len(image.shape) == 3:
                gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
            else:
                gray = image
            
            # Barcodes decode karo
            barcodes = pyzbar_decode(gray)
            
            for barcode in barcodes:
                data = barcode.data.decode('utf-8', errors='replace')
                barcode_type = barcode.type
                
                # Bounding rect
                rect = barcode.rect
                bbox = (rect.left, rect.top, rect.left + rect.width, rect.top + rect.height)
                
                results.append(BarcodeResult(
                    data=data,
                    barcode_type=barcode_type,
                    bbox=bbox
                ))
                
                logger.info(f"Barcode found: {barcode_type} = {data}")
            
        except ImportError:
            logger.warning("pyzbar not installed: pip install pyzbar")
        except Exception as e:
            logger.error(f"Barcode reading error: {e}")
        
        return results

    def extract_prices(self, text_results: List[OCRResult]) -> List[str]:
        """OCR text se prices extract karo"""
        prices = []
        
        combined_text = " ".join([r.text for r in text_results])
        
        for pattern in self.PRICE_PATTERNS:
            matches = re.findall(pattern, combined_text, re.IGNORECASE)
            prices.extend(matches)
        
        # Duplicates remove karo
        prices = list(dict.fromkeys(prices))
        return prices

    def _classify_text(self, text: str) -> str:
        """Text classify karo - price hai, brand hai, ya general"""
        text_lower = text.lower().strip()
        
        # Price check karo
        for pattern in self.PRICE_PATTERNS:
            if re.search(pattern, text, re.IGNORECASE):
                return "price"
        
        # Barcode/number check
        if re.match(r'^[\d\s\-]+$', text) and len(text) >= 8:
            return "barcode_text"
        
        # All caps - likely brand name
        if text.isupper() and len(text) > 2:
            return "brand"
        
        # MRP or weight indicators
        if any(kw in text_lower for kw in ["mrp", "weight", "net wt", "mfg", "exp", "batch"]):
            return "label_info"
        
        return "general"

    def analyze_product_text(self, image: np.ndarray) -> Dict:
        """
        Complete product text analysis karo
        
        Returns comprehensive dict with:
        - All extracted text
        - Prices found
        - Barcodes found
        - Brand candidates
        - Raw OCR results
        """
        analysis = {
            "all_text": [],
            "prices": [],
            "barcodes": [],
            "brands": [],
            "label_info": [],
            "full_text": "",
            "ocr_engine": "none"
        }
        
        # EasyOCR se text
        ocr_results = []
        if self.use_easyocr:
            ocr_results = self.extract_text_easyocr(image)
            analysis["ocr_engine"] = "easyocr"
        elif self.use_tesseract:
            ocr_results = self.extract_text_tesseract(image)
            analysis["ocr_engine"] = "tesseract"
        
        # Results categorize karo
        for result in ocr_results:
            analysis["all_text"].append({
                "text": result.text,
                "confidence": round(result.confidence, 3),
                "type": result.text_type
            })
            
            if result.text_type == "price":
                analysis["prices"].append(result.text)
            elif result.text_type == "brand":
                analysis["brands"].append(result.text)
            elif result.text_type == "label_info":
                analysis["label_info"].append(result.text)
        
        # Price patterns se bhi extract karo
        extracted_prices = self.extract_prices(ocr_results)
        analysis["prices"] = list(set(analysis["prices"] + extracted_prices))
        
        # Barcodes read karo
        barcode_results = self.read_barcodes(image)
        analysis["barcodes"] = [
            {"data": b.data, "type": b.barcode_type} for b in barcode_results
        ]
        
        # Full text combine karo
        analysis["full_text"] = " | ".join([r.text for r in ocr_results])
        
        return analysis

    def draw_ocr_results(self, image: np.ndarray,
                          results: List[OCRResult]) -> np.ndarray:
        """OCR results image pe visualize karo"""
        annotated = image.copy()
        
        type_colors = {
            "price": (0, 255, 0),       # Green
            "brand": (255, 165, 0),     # Orange
            "barcode_text": (255, 0, 0),# Blue
            "label_info": (255, 0, 255),# Magenta
            "general": (0, 255, 255),   # Cyan
        }
        
        for result in results:
            if result.bbox is None:
                continue
            
            color = type_colors.get(result.text_type, (0, 255, 255))
            
            # EasyOCR bbox format: list of 4 points
            if isinstance(result.bbox[0], (tuple, list)):
                pts = np.array(result.bbox, dtype=np.int32)
                cv2.polylines(annotated, [pts], True, color, 2)
                x, y = pts[0]
            else:
                x1, y1, x2, y2 = result.bbox
                cv2.rectangle(annotated, (x1, y1), (x2, y2), color, 2)
                x, y = x1, y1
            
            label = f"{result.text[:20]} ({result.text_type})"
            cv2.putText(annotated, label, (x, y - 5),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.5, color, 1)
        
        return annotated
